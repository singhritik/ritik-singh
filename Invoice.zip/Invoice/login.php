<!DOCTYPE html>
<html>
<head>
    <title>login</title>
</head>
<body>
    <div class="headr">
        <center><h1>Sign In</h1></center>
    </div>
    <table border='0' align='center' cellspacing="15px">
    <form method='post' action="logincheck.php">
        <tr>
            <td>
                Login Name
            </td>
            <td>
                <input type="text" name="uname" size="20" maxlength="20" required />
            </td>
        </tr>
        <tr>
            <td>
                Password
            </td>
            <td>
                <input type="password" name="upassword" size="20" maxlength="20" required />
            </td>
        </tr>
        
        <tr>
            <td colspan="2" align='center'>
                <input type="submit" value="Login" name="submit" />
                 
                 &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset" value="Reset" />
            </td>
            <td>
            </td>
        </tr>
        <tr>
            <td colspan="2" align='center'>
                <?php
                    if(isset($_REQUEST["err"]))
                        echo "Invalid Username or Password";
                ?>
            </td>
        </tr>
    </form>
</table>
<center><a href="register.php">Sign Up</a></center>
<br><br><br><br><br><br>
<center><label>Design by Ritik singh<label></center>
</body>
</html>