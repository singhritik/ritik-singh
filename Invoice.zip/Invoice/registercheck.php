<?php
 

        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "test";

        $conn = mysql_connect($host, $dbUsername, $dbPassword, $dbname);

        if(!$conn){
            die('Connect Error'. mysql_error());
        }
        mysql_select_db($dbname,$conn);    
        $sql= "INSERT into users (username, uname, upassword, email, mobile, city) values ('$_POST[username]', '$_POST[uname]','$_POST[upassword]','$_POST[email]','$_POST[mobile]','$_POST[city]')";

        if(!mysql_query($sql,$conn)){
            die('Error:'.mysql_error());
        }
        echo "Record Inserted";
        header("location:login.php");
        mysql_close($conn)
       
?>