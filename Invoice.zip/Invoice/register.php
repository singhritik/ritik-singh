<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<link rel="stylesheet" type="text/css" href="sytle.css">
</head>
<body>
	<center><div>
	<div class="headr">
		<center><h1>Sign Up</h1></center>
	</div>
	<form action="registercheck.php" method="post">
		<table cellspacing="15px">
			<tr>
				<td>Name</td>
				<td><input class="inp" type="text" name="username" placeholder="Name" required></td>
			</tr>
			<tr>
				<td>Username</td>
				<td><input class="inp" type="text" name="uname" placeholder="username" required></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input class="inp" type="Password" name="upassword" placeholder="Password" required></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input class="inp" type="text" name="email" placeholder="Email" required></td>
			</tr>
			<tr>
				<td>Mobile Number</td>
				<td><input class="inp" type="text" name="mobile" placeholder="Mobile Number" required></td>
			</tr>
			<tr>
				<td>City</td>
				<td><input class="inp" type="text" name="city" placeholder="City" required></td>
			</tr>
			<tr>
				<td><input class="btn" type="submit" name="submit" value="Submit"></td>
				<td><input class="btn" type="reset" name="reset" value="Reset"></td>
			</tr>
		</table>
	</form>
	</div>
	</div></center>
	<center><a href="login.php">Sign In</a></center><br><br><br><br><br>
	<center><label>Design by Ritik singh<label></center>
</body>
</body>
</html>