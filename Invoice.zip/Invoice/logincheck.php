<?php

	session_start();
	$Cser = mysqli_connect("localhost","root","","test") or die("Server connection failed : ".mysqli_error());
    $uname = $_REQUEST["uname"];
    $upassword = $_REQUEST["upassword"];
    
    $s = "select * from users where uname='".$uname."' and upassword='".$upassword."'";
    
    $result = mysqli_query($Cser,$s);
    
    $count = mysqli_num_rows($result);
    
    if($count>0)
    {
        $_SESSION["login"]=$uname;
        header("location:index.php");
    }
    else
    {
        header("location:login.php?err=1");
    }
?>