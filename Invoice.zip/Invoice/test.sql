-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 05, 2018 at 01:00 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE IF NOT EXISTS `details` (
  `invoiceid` int(10) NOT NULL,
  `cname` varchar(40) NOT NULL,
  `item` varchar(50) NOT NULL,
  `qnty` int(4) NOT NULL,
  `customercity` varchar(50) NOT NULL,
  `duedate` date NOT NULL,
  `issuedate` date NOT NULL,
  PRIMARY KEY (`invoiceid`),
  UNIQUE KEY `invoiceid` (`invoiceid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`invoiceid`, `cname`, `item`, `qnty`, `customercity`, `duedate`, `issuedate`) VALUES
(10009, 'ritesh', 'CPU', 2, 'Mahu', '2018-09-01', '2018-08-05'),
(20364, 'bhupendra', 'CPU', 5, 'dewas', '2018-09-01', '2018-08-05'),
(100005, 'abhi', 'keyboard', 5, 'bhopal', '2018-09-02', '2018-08-05'),
(254966, 'deepak', 'LCD', 3, 'ujjain', '2018-09-05', '2018-08-05'),
(654215, 'shivendra', 'Printer', 2, 'indore', '2018-09-02', '2018-08-05'),
(1000000006, 'rohan', 'LCD', 12, 'dewas', '2018-09-03', '2018-08-05');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `Sno` int(3) NOT NULL AUTO_INCREMENT,
  `itemname` varchar(20) NOT NULL,
  `itemcode` varchar(5) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`Sno`),
  UNIQUE KEY `itemname` (`itemname`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Sno`, `itemname`, `itemcode`, `price`) VALUES
(1, 'LCD', 'A12', 5000),
(2, 'Mouse', 'b13', 250),
(3, 'keyboard', '41c', 1500),
(4, 'CPU', 'v15', 10000),
(5, 'Printer', 'e45', 8000),
(6, 'Router', 'skd56', 15999);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(20) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `upassword` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  PRIMARY KEY (`uname`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `uname`, `upassword`, `email`, `mobile`, `city`) VALUES
('ritiksingh', 'admin', '123456', 'rs@gmail.com', '8269952793', 'Indore');
