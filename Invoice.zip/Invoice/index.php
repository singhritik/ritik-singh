<?php
	
	session_start();
    if(!isset($_SESSION["login"]))
        header("location:login.php");
    $r=$_SESSION["login"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>home</title>
</head>
<body>
    <div style="float:right; padding-right: 20px; padding-top: 20px;">
        <label style="font-size: 20px;"><?php echo $r ?></label>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="logout.php">Logout</a>
    </div>
    <div style="clear: both;"></div>
    <div class="headr">
        <center><h1>Create Invoice</h1></center>
    </div>
    <center><form action="select1.php" method="post">
        <table cellspacing="15px">
            <tr>
                <td>Invoice no</td>
                <td><input type="text" name="invoiceid" required=""></td>
            </tr>
            <tr>
                <td>Product name:</td>
                <td><select name="item">
                        <option value="none">none</option>
                        <option value="LCD">LCD</option>
                        <option value="Mouse">Mouse</option>
                        <option value="keyboard">keyboard</option>
                        <option value="CPU">CPU</option>
                        <option value="Printer">Printer</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Quantity</td>
                <td><input type="text" name="qnty"></td>
            </tr>
            <tr>
                <td>Customer name</td>
                <td><input type="text" name="cname" required></td>
            </tr>
            <tr>
                <td>Customer city</td>
                <td><input type="text" name="customercity"></td>
            </tr>
            <tr>
                <td>Due Date</td>
                <td><input type="text" name="duedate" placeholder="yyyy-mm-dd" required></td>
            </tr>
            <tr>
                <td>Issue Date</td>
                <td><input type="text" name="issuedate" placeholder="yyyy-mm-dd" required></td>
            </tr>
            <tr>
                <td>Subject</td>
                <td><input type="textarea" name="subject" required></td>
            </tr>
        </table>
        <input type="submit" value="Submit">
        </form></center><br><br><br><br><br><br>
	<center><label>Design by Ritik singh<label></center>
</body>
</html>
    